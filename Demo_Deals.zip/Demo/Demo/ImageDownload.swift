//
//  ImageDownload.swift
//  Demo
//
//  Created by User on 19/06/17.
//  Copyright © 2017 User. All rights reserved.
//

import Foundation
import UIKit
let imageCache = NSCache<AnyObject, AnyObject>()

extension UIImageView {
    func loadImageUsingCacheWithUrl(urlString: String) {
        self.image = nil
        
        // check for cache
        if let cachedImage = imageCache.object(forKey: urlString as AnyObject) as? UIImage {
            self.image = cachedImage
            return
        }
        // download image from url
        
        let url = URL(string: urlString)
        
        URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, error) -> Void in
            
            if error == nil{
                self.image = UIImage(data: data!)
            }else {
                return
            }
            
            DispatchQueue.main.async(execute: { () -> Void in
                imageCache.setObject(self.image!, forKey: urlString as AnyObject)
            })
        }).resume()
    }
}
