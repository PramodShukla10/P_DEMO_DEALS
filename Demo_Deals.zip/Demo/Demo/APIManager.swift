//
//  AppDelegate.swift
//  Demo
//
//  Created by User on 14/06/17.
//  Copyright © 2017 User. All rights reserved.
//

import UIKit
import SystemConfiguration
typealias StringConsumer = (_ result: [String :Any], _ error: NSError?) -> Void

let APIManagerSharedInstance = APIManager()

struct Constants {
    static let serverError = "Oops! Something went wrong!\nPlease try again."
    static let noInternet = "Internet connection not found, Please make sure that you are connected with internet."
   }

struct APIs {
    static let BASE_URL = "http://www.desidime.com/api/v1/"
    static let GET_DEALS = "premium_deals/list/"

}
class APIManager: NSObject {
    
    class var sharedInstance: APIManager {
        return APIManagerSharedInstance
    }
   
    func isNetworkConnected() -> Bool
    {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
    
    
    func callPostService(postdata:[String : AnyObject] = [:], urlString:String, consumer:@escaping StringConsumer) {
        
        let request : NSMutableURLRequest!
     
        request = self.doRequestWithURL(url: urlString)
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: request as URLRequest) {
            (data, response, error) in
            // check for any errors
            
            guard error == nil else {
                print("error calling GET on /todos/1")
                print(error!)
                
                let errorDict = ["errorcode":false,"errorstr":Constants.serverError] as [String : Any]
                consumer(errorDict as [String : Any] , nil)
                
                return
            }
            
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                
                let errorDict = ["errorcode":false,"errorstr":Constants.serverError] as [String : Any]
                consumer(errorDict as [String : AnyObject] , nil)
                
                return
            }
            
            // parse the result as JSON, since that's what the API provides
            do {
                
                guard let jsonDict:[String:AnyObject] = try JSONSerialization.jsonObject(with: responseData, options: JSONSerialization.ReadingOptions(rawValue: 0)) as? [String:AnyObject] else {
                    print("error trying to convert data to JSON")
                    
                    print(NSString(data: responseData, encoding: String.Encoding.utf8.rawValue)!)
                    
                    let errorDict = ["errorcode":false,"errorstr":Constants.serverError] as [String : Any]
                    consumer(errorDict as [String : Any] , nil)
                    return
                }
                consumer(jsonDict as [String : Any] , nil)
                
            } catch  {
                
                let res: String = String(data: responseData, encoding: String.Encoding.utf8)!
                print(" Error Res Str \(res)")
                print("error trying to convert data to JSON")
                
                let errorDict = ["errorcode":false,"errorstr":Constants.serverError] as [String : Any]
                consumer(errorDict as [String : Any] , nil)
            }
        }
        task.resume()
    }
   func doRequestWithURL(url:String) -> NSMutableURLRequest {

       let request = NSMutableURLRequest()
       request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringLocalCacheData
       request.timeoutInterval = 120
       request.httpMethod = "POST"
       request.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")

       // set URL
       let completeURL = APIs.BASE_URL + (url as String)
       request.url = NSURL.init(string: completeURL as String) as URL?
       return request
   }
}
