//
//  ViewController.swift
//  Demo
//
//  Created by User on 14/06/17.
//  Copyright © 2017 User. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    
    
    var dealsDic = [String : Any]()
    var dealsArray = [[String : Any]]()

    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var progressIndicator: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tblView.estimatedRowHeight = 110
        tblView.rowHeight = UITableViewAutomaticDimension
        self.loadData()
        
    }
    
    @IBAction func segemntBtnAction(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0 {
            self.dealsArray = self.dealsDic["top"] as! [[String : Any]]
        }else{
            self.dealsArray = self.dealsDic["popular"] as! [[String : Any]]
        }
        tblView.reloadData()
    }
    
    // Mark : web api call
    
    func loadData() {
        
        if APIManagerSharedInstance.isNetworkConnected() {
            
            self.progressIndicator.startAnimating()
            
            
            APIManagerSharedInstance.callPostService(urlString: APIs.GET_DEALS , consumer: { (result, error) in
                DispatchQueue.main.async {
                    self.progressIndicator.stopAnimating()
                    print("Response: \(result)")
                    
                    if (result["errorcode"]as!String == "0") {
                        
                        self.dealsDic = result["result"] as! [String : Any]
                        
                        self.dealsArray = self.dealsDic["top"] as! [[String : Any]]
                        
                        self.tblView.reloadData()
                        
                    }else {
                        self.showAlert(message: result["errorstr"] as! String)
                    }
                }
                
            })
         
        }else {
            self.showAlert(message: Constants.noInternet)
        }
        
    }
    
    // Mark : Alert
    func showAlert(message:String)
    {
        let alert = UIAlertController(title: "", message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            
        }))
        
        present(alert, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Mark : Table View delegate and datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
        return dealsArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")as!CustomCell
        
        let dealsDic = dealsArray[indexPath.row]
        cell.title.text = dealsDic["title"] as? String
        cell.detail.textFrom(html: (dealsDic["deal_detail"] as? String)!)
        cell.img.loadImageUsingCacheWithUrl(urlString: (dealsDic["pic_thumb"] as? String)!)
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
   
}

