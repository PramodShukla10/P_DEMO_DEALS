//
//  HtmlString.swift
//  Demo
//
//  Created by User on 02/07/17.
//  Copyright © 2017 User. All rights reserved.
//

import Foundation
import UIKit
extension UILabel {
    func textFrom(html: String) {
        if let htmlData = html.data(using: String.Encoding.unicode) {
            do {
                self.attributedText = try NSAttributedString(data: htmlData,options: [NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType],documentAttributes: nil)
            } catch let e as NSError {
                print("Couldn't parse \(html): \(e.localizedDescription)")
            }
        }
    }
}
